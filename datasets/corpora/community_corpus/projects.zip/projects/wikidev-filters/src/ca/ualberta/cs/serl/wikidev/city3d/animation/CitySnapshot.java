package ca.ualberta.cs.serl.wikidev.city3d.animation;

public class CitySnapshot {
	
	

}
